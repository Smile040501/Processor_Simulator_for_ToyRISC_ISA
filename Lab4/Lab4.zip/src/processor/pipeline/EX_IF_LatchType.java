package processor.pipeline;

public class EX_IF_LatchType {
	
	public EX_IF_LatchType()
	{
		
	}

}
